import React from "react";

const Navbar = () => {
  return <div className="nav">Navbar</div>;
};

export default Navbar;
