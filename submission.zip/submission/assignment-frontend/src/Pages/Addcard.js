import React from "react";
import Form from "../Components/Form";

const Addcard = () => {
  return (
    <>
      <Form />
    </>
  );
};

export default Addcard;
